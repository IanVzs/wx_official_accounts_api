import requests
url = "http://127.0.0.1:8979/wx_service/refreshtoken"
requests.request("GET", url)
